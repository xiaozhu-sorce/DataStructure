#define MAX_STR_LEN 40
typedef char SString[MAX_STR_LEN + 1]; //0号单元存放串的长度 